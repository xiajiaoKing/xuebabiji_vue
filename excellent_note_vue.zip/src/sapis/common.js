/**
 * create by : TenzeTseng
 * 通用服务API模块
 */
export default {
  uploadFile: '/upload/flie'
}
