/**
 * create by : TenzeTseng
 * 登录服务API模块
 */
export default {
  doLogin: '/login/check',
  getVerifyCode: '/get/code',
  getStatus: '/get/status',
  doLogout: '/logout'
}
