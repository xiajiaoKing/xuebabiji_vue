export default {
  applicationName: 'xxxxx系统'
}
