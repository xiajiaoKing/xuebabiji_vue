<template>
    <div>
     
    </div>
</template>

<script>

export default {

  data () {
    return {
     
    }
  },
  components: {
   
  },

  created () {
   
  },
  activated () {
   
  },
  deactivated () {
   
  },
  methods: {
  
  }
}

</script>

